<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link href="http://fonts.cdnfonts.com/css/instruction" rel="stylesheet">

	<script type="text/javascript">
		function openMenu(){
			document.getElementById('menu').style.width = '250px';
		}

		function closeMenu(){
			document.getElementById('menu').style.width = '0px';
		}
	</script>
</head>
<body>
	<header id="mcontrol">
		<a href="#" class="btn-open" onclick="openMenu()"><i class="fas fa-list"></i> Menu</a>
	</header>

	<nav id="menu">
		<a href="#" onclick="closeMenu()"><i class="fas fa-times"></i> Close</a>
		<a href="index.php"><i class="fas fa-user-astronaut"></i> Pilot</a>
		<a href="index.php"><i class="fas fa-space-shuttle"></i> Transport</a>
		<a href="index.php"><i class="fas fa-file-signature"></i></i> Contracts</a>
	</nav>

	<div id="parent">
	  <div id="wide">
	  	<form id="form" method="post" action="controller/pilot.php">
	  		<label>Insert pilot informations</label>
	  		<input type="text" id="fname" name="certification" maxlength="5" placeholder="Certification" required>
	  		<input type="text" name="name" maxlength="10" placeholder="Name" required>
	  		<input type="text" name="age" maxlength="5" placeholder="Age" required>
	  		<input type="text" name="credits" maxlength="5" placeholder="Credits" required>
	  		<input type="text" name="location" maxlength="10" placeholder="Location" required>
	  		<input type="submit" value="Submit">
	  	</form>
	  </div>
	</div>

	<div id="parent">
	  <div id="wide">
	  	<table>
	  		<label>All pilot registers</label>
			<thead>
				<tr>
					<th>Certification</th>
					<th>Name</th>
					<th>Age</th>
					<th>Credits</th>
					<th>Location</th>
					<th>Manage</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>0</td>
					<td>Nome</td>
					<td>Age</td>
					<td>Credits</td>
					<td>Location</td>
					<td><a href="#"><i class="fas fa-trash-alt" style="font-size: 1.5em; padding-top: 5px; padding-bottom: 5px; color: #101010;"></i></a></td>
				</tr>
			</tbody>
		</table>
	  </div>
	</div>

</body>
</html>