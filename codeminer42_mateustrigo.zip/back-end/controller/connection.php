<?php

$hostname = "localhost";
$user = "root";
$pass = "";
$bd = "federation";

$link = new mysqli($hostname, $user, $pass, $bd);

if($link->connect_errno){
	echo "Error.";
}

?>