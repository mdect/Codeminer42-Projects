<?php

include('connection.php');

$certification = $_POST["certification"];
$name = $_POST["name"];
$age = $_POST["age"];
$credits = $_POST["credits"];
$location = $_POST["location"];

$query = "INSERT INTO pilots (certification, name, age, credits, location) VALUES ('$certification', '$name', '$age
', '$credits', '$location')";

mysqli_query($link, $query);

header("back-end/index.php");

?>