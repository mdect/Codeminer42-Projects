<?php

include('controller/connection.php');

if(isset($_GET['pid'])) {

    $pid = $_GET['pid'];
} else {
	$pid = 0;
}

//Patients

$queryp = "SELECT * FROM patients WHERE patientid = '$pid'";

$queryr = mysqli_query($link, $queryp);

$resultrows = mysqli_num_rows($queryr);

if($resultrows > 0){

	$queryi = mysqli_fetch_assoc($queryr);
} else{

	header('location: index.php');
}

//Appointments

$queryapp = "SELECT * FROM appointments WHERE patientid = '$pid' ORDER BY startime DESC";

$queryappr = mysqli_query($link, $queryapp);

$appresultrows = mysqli_num_rows($queryappr);

if($appresultrows > 0){

	$appqueryi = mysqli_fetch_assoc($queryappr);
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Front-end</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link href="http://fonts.cdnfonts.com/css/evolventa" rel="stylesheet">

	<script type="text/javascript">
		function openMenu(){
			document.getElementById('menu').style.width = '250px';
		}

		function closeMenu(){
			document.getElementById('menu').style.width = '0px';
		}
	</script>
</head>
<body>
	<header id="mcontrol">
		<a href="#" class="btn-open" onclick="openMenu()"><i class="fas fa-list"></i> Menu</a>
	</header>

	<nav id="menu">
		<a href="#" onclick="closeMenu()"><i class="fas fa-times"></i> Close</a>
		<a href="index.php"><i class="fas fa-user-md"></i> Doctor</a>
	</nav>

	<header>
		<h4>Dashboard</h4>
	</header>

	<div id="parent">
		<div id="wide">
			<h3 id="info">Patient info</h3>
			<h2><?php echo $queryi['name'];?></h2>
			<p id="pid"><?php echo $queryi['document'];?></p>
		</div>
		<div id="wide">
			<h3 id="info">Plan info</h3>
			<h2><?php echo $queryi['insuranceplan'];?></h2>
			<p id="pid"><?php echo $queryi['healthsystemid'];?></p>
		</div>
		<div id="wide">
			<h3 id="info">Lastest App.</h3>
			<h2><?php echo $appqueryi['specialty'];?></h2>
			<p id="pid"><?php echo $appqueryi['startime'];?></p>
		</div>
	</div>

	<div id="relatoryoptions">
		<button id="optionselected" style="cursor: pointer;">Recent</button>
		<button id="option" style="cursor: pointer;">Upcoming</button>
		<button id="option" style="cursor: pointer;">History</button>
	</div>

	<?php while($appqueryi = mysqli_fetch_assoc($queryappr)) { ?>
	<div id="parent">
		<div id="relatory">
			<?php if(isset($appqueryi) AND $appqueryi['type'] == "firstVisit"){ ?>
			<h4 id="inforelatory"><i class="fas fa-briefcase-medical"></i> <?php echo $appqueryi['startime'] ?></h4>
			<?php }	?>
			<?php if(isset($appqueryi) AND $appqueryi['type'] == "exam"){ ?>
			<h4 id="inforelatory"><i class="fas fa-file-medical-alt"></i> <?php echo $appqueryi['startime'] ?></h4>
			<?php }	?>
			<?php if(isset($appqueryi) AND $appqueryi['type'] == "checkUp"){ ?>
			<h4 id="inforelatory"><i class="fas fa-notes-medical"></i> <?php echo $appqueryi['startime'] ?></h4>
			<?php }	?>
			<?php if(isset($appqueryi) AND $appqueryi['type'] == "surgery"){ ?>
			<h4 id="inforelatory"><i class="fas fa-procedures"></i> <?php echo $appqueryi['startime'] ?></h4>
			<?php }	?>
			<?php if(isset($appqueryi) AND $appqueryi['type'] == "followUp"){ ?>
			<h4 id="inforelatory"><i class="fas fa-stethoscope"></i> <?php echo $appqueryi['startime'] ?></h4>
			<?php }	?>
		</div>
		<div id="relatory">
			<h4 id="inforelatory"><?php echo $appqueryi['type'] ?></h4>
		</div>
		<div id="relatory">
			<?php if(isset($appqueryi) AND $appqueryi['status'] == "absent"){ ?>
			<h4 id="absent" style="background-color: #ff3333"><?php echo mb_strtoupper($appqueryi['status']) ?></h4>
			<?php } ?>
			<?php if(isset($appqueryi) AND $appqueryi['status'] == "completed"){ ?>
			<h4 id="absent" style="background-color: #33cc66;"><?php echo mb_strtoupper($appqueryi['status']) ?></h4>
			<?php } ?>
			<?php if(isset($appqueryi) AND $appqueryi['status'] == "pending"){ ?>
			<h4 id="absent" style="background-color: #3366cc;"><?php echo mb_strtoupper($appqueryi['status']) ?></h4>
			<?php } ?>
			<?php if(isset($appqueryi) AND $appqueryi['status'] == "cancelled"){ ?>
			<h4 id="absent" style="background-color: #333;"><?php echo mb_strtoupper($appqueryi['status']) ?></h4>
			<?php } ?>
		</div>
	</div>
	<?php }	?>


	<?php if($appresultrows === 0){ ?>
	<div id="parent">
		<div id="relatory">
			<h4 id="inforelatory">No data found</i></h4>
		</div>
	</div>
	<?php } ?>
</body>
</html>