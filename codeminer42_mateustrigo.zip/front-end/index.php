<?php

include('controller/connection.php');

$queryapp = "SELECT appointments.type, appointments.startime, patients.name, appointments.status FROM appointments, patients ORDER BY startime DESC";

$queryappr = mysqli_query($link, $queryapp);

$appresultrows = mysqli_num_rows($queryappr);

if($appresultrows > 0){

	$appqueryi = mysqli_fetch_assoc($queryappr);
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Front-end</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link href="http://fonts.cdnfonts.com/css/evolventa" rel="stylesheet">

	<script type="text/javascript">
		function openMenu(){
			document.getElementById('menu').style.width = '250px';
		}

		function closeMenu(){
			document.getElementById('menu').style.width = '0px';
		}
	</script>
</head>
<body>
	<header id="mcontrol">
		<a href="#" class="btn-open" onclick="openMenu()"><i class="fas fa-list"></i></i> Menu</a>
	</header>

	<nav id="menu">
		<a href="#" onclick="closeMenu()"><i class="fas fa-times"></i> Close</a>
		<a href="index.php"><i class="fas fa-user-md"></i> Doctor</a>
	</nav>

	<header>
		<h4>Dashboard</h4>
	</header>

	<section id="calendar">
		<table>
		  <h1>Calendar</h1>
		  <thead>
		  	<tr>
		      <th id="hour"></th>
		      <th id="hour">Mon</th>
		      <th id="hour">Tue</th>
		      <th id="hour">Wed</th>
		      <th id="hour">Thu</th>
		      <th id="hour">Fri</th>
		    </tr>
		  </thead>
		  <tbody>
		    <tr>
		      <td id="hour">9:00</td>
		      <td></td>
		      <td></td>
		      <td></td>
		      <td></td>
		      <td></td>
		    </tr>
		    <tr>
		      <td id="hour">9:30</td>
		      <td></td>
		      <td style="background-color: #3399ff;"><a href="patient.php?pid=1" style="color: white; display: block; width: 100%;">[Jack Santiago]<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a></td>
		      <td></td>
		      <td></td>
		      <td></td>
		    </tr>
		    <tr>
		      <td id="hour">10:00</td>
		      <td></td>
		      <td style="background-color: #3399ff;"><a href="patient.php?pid=2" style="color: white; display: block; width: 100%;">[Brett Brady]<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a></td>
		      <td></td>
		      <td></td>
		      <td></td>
		    </tr>
		    <tr>
		      <td id="hour">10:30</td>
		      <td></td>
		      <td style="background-color: #3399ff;"><a href="patient.php?pid=3" style="color: white; display: block; width: 100%;">[Rachel Francis]<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a></td>
		      <td></td>
		      <td style="background-color: #3399ff;"><a href="patient.php?pid=4" style="color: white; display: block; width: 100%;">[Ora Dean]<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a></td>
		      <td></td>
		    </tr>
		    <tr>
		      <td id="hour">11:00</td>
		      <td></td>
		      <td style="background-color: #3399ff;"><a href="patient.php?pid=6" style="color: white; display: block; width: 100%;">[Lucy Yates]<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a></td>
		      <td></td>
		      <td></td>
		      <td></td>
		    </tr>
		  </tbody>
		</table>
	</section>

	<section id="history">
		<table>
			<h1>History</h1>
			<?php while($appqueryi = mysqli_fetch_assoc($queryappr)) { ?>
		  	<tr>
		    <td><?php echo $appqueryi['startime'] ?></td>
		    <?php if(isset($appqueryi) AND $appqueryi['status'] == "absent"){ ?>
		    <td style="background-color: #ff3333; color: white;"><?php echo mb_strtoupper($appqueryi['status']) ?></td>
		    <?php } ?>
		    <?php if(isset($appqueryi) AND $appqueryi['status'] == "completed"){ ?>
		    <td style="background-color: #33cc66; color: white;"><?php echo mb_strtoupper($appqueryi['status']) ?></td>
		    <?php } ?>
		    <?php if(isset($appqueryi) AND $appqueryi['status'] == "pending"){ ?>
		    <td style="background-color: #3366cc; color: white;"><?php echo mb_strtoupper($appqueryi['status']) ?></td>
		    <?php } ?>
		    <?php if(isset($appqueryi) AND $appqueryi['status'] == "cancelled"){ ?>
		    <td style="background-color: #333; color: white;"><?php echo mb_strtoupper($appqueryi['status']) ?></td>
		    <?php } ?>
		    <td><?php echo $appqueryi['name'] ?></td>
		    <?php if(isset($appqueryi) AND $appqueryi['type'] == "firstVisit"){ ?>
		    <td><i class="fas fa-briefcase-medical"></i> <?php echo mb_strtoupper($appqueryi['type']) ?></td>
			<?php } ?>
			<?php if(isset($appqueryi) AND $appqueryi['type'] == "exam"){ ?>
		    <td><i class="fas fa-file-medical-alt"></i> <?php echo mb_strtoupper($appqueryi['type']) ?></td>
			<?php } ?>
			<?php if(isset($appqueryi) AND $appqueryi['type'] == "checkUp"){ ?>
		    <td><i class="fas fa-notes-medical"></i> <?php echo mb_strtoupper($appqueryi['type']) ?></td>
			<?php } ?>
			<?php if(isset($appqueryi) AND $appqueryi['type'] == "surgery"){ ?>
		    <td><i class="fas fa-procedures"></i></i> <?php echo mb_strtoupper($appqueryi['type']) ?></td>
			<?php } ?>
			<?php if(isset($appqueryi) AND $appqueryi['type'] == "followUp"){ ?>
		    <td><i class="fas fa-stethoscope"></i> <?php echo mb_strtoupper($appqueryi['type']) ?></td>
			<?php } ?>
		  </tr>
		  <?php } ?>
		</table>
	</section>
</body>
</html>