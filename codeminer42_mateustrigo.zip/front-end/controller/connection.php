<?php

$hostname = "localhost";
$user = "root";
$pass = "";
$bd = "hospital";

$link = new mysqli($hostname, $user, $pass, $bd);

if($link->connect_errno){
	echo "Error.";
}

?>