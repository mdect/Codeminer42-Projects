-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 25-Maio-2021 às 05:49
-- Versão do servidor: 10.4.17-MariaDB
-- versão do PHP: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `hospital`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `patientid` int(50) NOT NULL,
  `specialty` text NOT NULL,
  `type` text NOT NULL,
  `description` text NOT NULL,
  `notes` text NOT NULL,
  `status` text NOT NULL,
  `startime` text NOT NULL,
  `endtime` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `appointments`
--

INSERT INTO `appointments` (`id`, `patientid`, `specialty`, `type`, `description`, `notes`, `status`, `startime`, `endtime`) VALUES
(1, 6, 'cardiology', 'exam', 'Ebomak ler sen uke funepzez ses beoci vine ojagorih ofi zirumegij ris.', 'Neb kevocowik nasmek ojlovgoj mupwoga zar gabuc cucak irajifwej co mawuwpe ruhhez kacolo aguper sihbodek wu.', 'cancelled', '2021-05-09T150000.327Z', '-'),
(2, 1, 'neurology', 'checkUp', 'Urtu waip ut moegavap riepeli zaavgi edumek foelfu niv wib lor gi bajuv icoruuv adahec seiwe cu.', '', 'absent', '2021-05-09T13:00:00.327Z', '-'),
(3, 1, 'general', 'followUp', 'Igahona ufeibo dectivim kiv gides medak atkimwez nirsemloz becties vagunpi mo popud dinil ceczil uk zavage navavak roda.', 'Vis jukjawiza dedukamuf veez doite latdutpug wapcihja je lepip ibi ij muv cigri adoenaode seasra.', 'cancelled', '2021-05-08T15:00:00.327Z', '-'),
(4, 6, 'general', 'firstVisit', 'Lohto dosfid orupaf ewo mermo dope me hof ez carnuj zeguuja wuvhade vumero ejegebed iv luni marda futut.', '', 'absent', '2021-05-12T15:00:00.327Z', '-'),
(5, 15, 'general', 'followUp', 'Lovot fimiwdo femham bonese bofe weleh mihlofo ra zi huj mam kemlisaw.', '', 'cancelled', '2021-05-09T13:00:00.327Z', '-'),
(6, 10, 'neurology', 'firstVisit', 'Evzesse rizan distu go lomperbe sonal vemjo ruhimhe ki le wutdore casogji erdobdow zodataguv lajok idaso.', 'Um taggu jauj leem ogwohuji op ufeafu ricsamzi cesbor firavauhe juhsado vamizfu.', 'completed', '-', '2021-05-09T17:30:00.327Z'),
(7, 12, 'cardiology', 'exam', 'Jusa voluse hussi alwaknul ihevinom ri kiharjop pugenhe noawzoz heope ke jekavlup ceni jojegaw wahtaf na.', 'Pohijap rudir icinioro ve gun aznegib jed ase icceg ce vasup gusif zurboopi.', 'completed', '2021-05-10T14:00:00.327Z', '2021-05-10T14:30:00.327Z'),
(8, 5, 'neurology', 'checkUp', 'Jaodaapa zeudi gehuh bomenno zu wat gugom ibcoriji ja legpe wis fantor dep honub tekba ja.', '', 'completed', '2021-05-12T15:00:00.327Z', '2021-05-12T14:30:00.327Z'),
(9, 9, 'general', 'firstVisit', 'Ejuadi tokil gawbuwu vicekedi vomok napavugi kus ire ufifajhiz lubo nukbuca kualnib deb ni homoko cujedhu bi wopimuv.', 'Nahhe cap la un pu ofupaji mabija suhhojoh wam keonuzef vudwer perigbog se.', 'absent', '2021-05-08T11:30:00.327Z', '-'),
(10, 3, 'cardiology', 'followUp', 'Lu teh mu we lev ni uktu etsinri zudgu hefake zacza rarag vap bej voh obi cel.\',\r\n\'Apa kedi zahcuvro za emmop mik posjewron ip ekfigip bofko oceego vazhozse diwef hejbimas eg hikagum.', '-', 'cancelled', '2021-05-07T16:00:00.327Z', ''),
(11, 6, 'cardiology', 'exam', 'Re hopruwe wacofo ce mido orieri cekosi zizidepo bu ocri wovug pugasu jiwfa sosen.\',\r\n\'Galog eprabfo ze uwofuw mizzebcoh sap gif hik ovkenham orcu geek mamur ve imgiafi salcilejo sa siki lijkopu.', '', 'completed', '2021-05-12T09:30:00.327Z', '2021-05-12T10:30:00.327Z'),
(12, 7, 'neurology', 'firstVisit', 'Hu cu rudanu sa giz numpubzej fa zuadho loca rifuc la lus burojo.', '', 'completed', '2021-05-09T14:00:00.327Z', '2021-05-09T14:30:00.327Z'),
(13, 14, 'cardiology', 'checkUp', 'Zezawep tudpib icdege wabsevla vo tud regdi emetahna pog jowed moeji le me rijjifda jak memuhcep.', 'Bij cem letajde zibmumu vu kiup owfom lesew bap hecaeka posa rafte.', 'completed', '2021-05-09T15:00:00.327Z', '2021-05-09T16:00:00.327Z'),
(14, 8, 'cardiology', 'firstVisit', 'Pakanum poj gibopor mi otlik bismo epueleri olizieho rajdo diobi ib humku cip ravofhid sova ibatarpa ce rer.', 'Ov zuilwi duf leof ijizuloc decwajhah docrabi mo sugilpi zov dur bozitpah ihaibupew net.', 'completed', '2021-05-07T12:30:00.327Z', '2021-05-07T13:00:00.327Z'),
(15, 13, 'general', 'checkUp', 'Zuhoce wi sir iwo ekorelat gopajib fobko empezag as behonse ludefbu teppum sa lobigpuw be tawu fuhacuf kucun.', '', 'completed', '2021-05-11T10:30:00.327Z', '2021-05-11T11:00:00.327Z'),
(16, 4, 'cardiology', 'surgery', 'Fapvo faz micozpa gum mo jadla jozufe nun jatvowon tud vi ko no ekuruzo.', '', 'cancelled', '2021-05-19T15:00:00.327Z', ''),
(17, 7, 'general', 'surgery', 'Moazo zactej dolaguse zod guhepoze ecionu catpudkem areduvos hi lenmu be hi fa fumgiubi likhe.', '', 'cancelled', '2021-05-14T13:30:00.327Z', ''),
(18, 3, 'cardiology', 'exam', 'Isacup lubot ho wut jewko secugub ib pakdar jihizugi hen uso sofzod docobtuk rob giwsevap afu.', 'Bomjep luvojgun liwu vid ze okze la micpan kate nugcil sa uhikor.', 'cancelled', '2021-05-17T12:00:00.327Z', ''),
(19, 15, 'cardiology', 'followUp', 'Cetawsit gej egiiro duflaoz zigenwip na wucerpim gonvujri nibbeg oba mosaccik coz am ibemenhod.', '', 'completed', '2021-05-17T17:30:00.327Z', '2021-05-17T18:00:00.327Z'),
(20, 10, 'cardiology', 'checkUp', 'Nisa so zaika ti votobwod letzon ni ecusic hasi ih fa garak.', '', 'absent', '2021-05-19T11:30:00.327Z', ''),
(21, 12, 'neurology', 'surgery', 'Ciar den kifugzug veh pivemso gopod fi jizu tot giubtor ve uniloleg jizsa fow dipsi isi.', '', 'cancelled', '2021-05-17T09:30:00.327Z', ''),
(22, 1, 'cardiology', 'checkUp', 'Zolnileto mibfuw zukusci vevi puvurhe vuhozus ebohiov pu vo babomuv te nubda gen jauli fuwfawu gah ala icimuru.', '', 'absent', '2021-05-16T11:00:00.327Z', ''),
(23, 14, 'general', 'exam', 'Rebdej unrot iru doccogus od vepemviw junica cona hi pupi gofe uvi.', 'Johakes pefhi opeuk ferezwah bu tuttan wathedun amuzigor fivhuh kuz zipdiser olonoffo giwahpid cakemidu ma.', 'absent', '2021-05-17T13:00:00.327Z', ''),
(24, 13, 'general', 'firstVisit', 'Zim devu urwuli junzifuv med cak sucud furziwbij cadihaf gegolcip ihfah hahpon.', '', 'completed', '2021-05-14T16:00:00.327Z', '2021-05-14T16:30:00.327Z'),
(25, 10, 'cardiology', 'checkUp', 'Cod aviri ujobeti nakti pej ham anlu optedu kiluut luciz wahfi johul vohinko ar tusve wazo kajam.', 'Sufuw cinaga hek dipeha ithe tigmagci uztaw paazo na dagud cadda cubfusah tediev.', 'absent', '2021-05-19T16:30:00.327Z', ''),
(26, 15, 'neurology', 'surgery', 'Bop temsibi gomkic zova riik uz gulcop sa veb jelleceh apu ut emalocej afide zodroltem weswazu.', '', 'cancelled', '2021-05-16T14:30:00.327Z', ''),
(27, 2, 'neurology', 'checkUp', 'Kavco rom fabamiw mateehe duvi dutuwbep zaleib bagek pi cumva taljubog wacdu nojoc duc kuha.', '', 'absent', '2021-05-18T12:00:00.327Z', ''),
(28, 4, 'neurology', 'followUp', 'Fobboceg kup lem uticase fifeku ci pucegno hubtamido umewaito ore fav doipgis.', 'Cejir ka mak gezdi ave nur upa egmelot isku bemeb lopec okocebe do ku ut mijgojito jecog.', 'absent', '2021-05-19T14:30:00.327Z', ''),
(29, 8, 'neurology', 'exam', 'Irfe dorkit bucenisu muziwjop wagegpi ji ese vujukuf ze bu miulo tuwmokri.', '', 'cancelled', '2021-05-14T16:30:00.327Z', ''),
(30, 4, 'cardiology', 'followUp', 'Ka cuv parfob zo asirolaj ze sedloj cobsej pefzi kewuv walaj awlubeh ihituc olbukwec wuh degi.', '', 'absent', '2021-05-16T13:30:00.327Z', ''),
(31, 10, 'general', 'followUp', 'Serlah jakwido womweka sig ugbalure gakis do jogiv etja zitez sog su kupevfu sidiril nezju wup oberinot.', '', 'completed', '2021-05-19T15:00:00.327Z', '2021-05-19T16:00:00.327Z'),
(33, 2, 'neurology', 'surgery', 'Bemsawdol ha kum ni zak oda boz gopinte rouvi ibifaf za lo voli gefwihfu amepan.', '', 'pending', '2021-05-21T17:00:00.327Z', ''),
(34, 15, 'cardiology', 'surgery', 'Vurbek lukapheg aktilhu zikuzbif zoc ujieduhav vej ivvot lenisru zikecenet maune ho iwusulos.', '', 'completed', '2021-05-20T14:30:00.327Z', '2021-05-20T15:30:00.327Z'),
(36, 3, 'neurology', 'surgery', 'Nul hivespev eficavzev fismilo tomok ru iduti sim padhi hetunjo lasov lazil atdek tehdubwe lezko up ecumhu zimuvse.', '', 'absent', '2021-05-18T10:00:00.327Z', ''),
(37, 10, 'general', 'exam', 'Toumeveg secajwe zutejpow wav vilag oheidnic sivvu rikge evo ibejucon ewde sukik uno joel.', 'Geje neciftof se lihgufnaz bocizonu fecev salsotos tij asibe balu pasji jiophap leb diwdur isipute sivezadip cufzujoh.', 'completed', '2021-05-21T13:00:00.327Z', '2021-05-21T14:00:00.327Z'),
(38, 8, 'cardiology', 'followUp', 'Muzgij poczaj gogooj vopezeb luwadzip novgalti ase kid gugzos fub mazimaw wez ka fekauz oseubu jesbuho rekze.', '', 'cancelled', '2021-05-20T14:00:00.327Z', ''),
(40, 1, 'neurology', 'exam', 'Ledvagew sorogalo it eguwahev kavrimuh fibukud udjabup voz ipe coamo obcujko jeblipuve.', 'Ku pura sa naf lerfe cazjeke fofobzeh pijsa jetcokil zawvalto cafud numbucod vazahusi welogi vekufofaf muzedurus.', 'pending', '2021-05-21T16:30:00.327Z', ''),
(41, 15, 'cardiology', 'firstVisit', 'Imocuttej tedna igirotod ciw dik nutiliwu lev riuf tagor ehauwdok gudi daj hujomah.', '', 'cancelled', '2021-05-19T12:30:00.327Z', ''),
(42, 11, 'neurology', 'firstVisit', 'Saz rosivec jechas ajajusje sozas pupudif tuhe iso hipmal romuot vufcu mubba rucpopur iv memetoobo jetdac.', 'Raoga potvice illa efi kiw lof losvucju wat sudsigce akkec zepjen wihce soobi vecegju.', 'cancelled', '2021-05-18T11:30:00.327Z', ''),
(44, 14, 'neurology', 'surgery', 'Na jabibmu tegeepo ozeocafa ov he ijueb ujukka zafudu koc ahutu ideda ap.', '', 'absent', '2021-05-21T15:00:00.327Z', ''),
(45, 3, 'neurology', 'firstVisit', 'Okeeb giguhsej kecag zu kurbeeke bu vab lotugu po ligzapir kiwmi cok cuic webe.', '', 'absent', '2021-05-20T12:30:00.327Z', ''),
(46, 6, 'cardiology', 'exam', 'Nilinur ujlakima acuhanhi ezible zo if lag bied danen fov pel muewzip ipa ad jaip.', 'Bivenit azaeteke hase dulboin leple bubsilu pewpa oza ah guv lemaw ino bo.', 'cancelled', '2021-05-19T16:00:00.327Z', ''),
(47, 3, 'neurology', 'exam', 'Vol kidpum ubujik londetog vi lag gab ranisi mujmutov wohoh iwcazo ehraul hotab hisnoege cadujovaw ohuze wuitagiw pu.', 'Pologeb utsed kem uwaisme cowouz cod taca itufozos rakat bepivmun holof cir rub.', 'absent', '2021-05-21T12:30:00.327Z', ''),
(48, 8, 'general', 'firstVisit', 'Kocrudi buumzac dowlur bim vof abicoz huj iwmuge sikcolkuz zoceh haifas da torucsez serol docer zodobjep kuih.', '', 'completed', '2021-05-21T10:30:00.327Z', '2021-05-21T11:30:00.327Z'),
(51, 13, 'cardiology', 'followUp', 'Kiz wagejmej kisa bi sufe wuimeda ni ejukom levrem biomo meeke aco imveuge wu papulutog.', '', 'pending', '2021-05-21T18:00:00.327Z', ''),
(52, 3, 'neurology', 'exam', 'Vejrased kut zehicufe gu tekhi zeduuni jospil ra zitoltoz wed bip sipuse lohil wu.', '', 'cancelled', '2021-05-19T11:00:00.327Z', ''),
(53, 3, 'general', 'surgery', 'Uj cabarsit woetgok pe on avutu widacow fa telisesem suso soziwib etafeb ve zesjerad lisza.', '', 'cancelled', '2021-05-20T09:30:00.327Z', ''),
(54, 12, 'cardiology', 'surgery', 'Kut uro imumibboh emoze juj ca jahnip bune sefum wefsarew rafi cew.', '', 'absent', '2021-05-19T10:00:00.327Z', ''),
(55, 14, 'cardiology', 'surgery', 'Onjakhu gihojda juzguc lucafvi up cohepesa ro marud kofgabed ciziz pow mi wuj at gonlo va oloil cakedces.', 'Vedliko licauc taiju ructo nezalgur juwu socme matunom ba kobcu kohegna radku bootamu nuvuja tueziku mebfet gescodas.', 'completed', '2021-05-19T09:00:00.327Z', '2021-05-19T10:00:00.327Z'),
(57, 2, 'cardiology', 'checkUp', 'Bescefre envegfok cacop omhav neste bilatto orraf us ov pa jeaslub rabwu nucjobvi ad sahti lacla.', 'Fewtu kujdili seubafoh poib zudlaf irawos vifopo guwahup cejuto ocomudo ino sumlebrug pe muldewe hosza cebbupo.', 'absent', '2021-05-20T14:00:00.327Z', ''),
(58, 6, 'neurology', 'firstVisit', 'Pufodfuw lepbafwa gogen uzza di bi az som uta kep ijnocjot fi eriasi si gatedos ceh kol.', '', 'cancelled', '2021-05-19T09:00:00.327Z', ''),
(59, 8, 'neurology', 'exam', 'Haumeow obopub usila hi jemeita zefobzud ize albe vorcalal civvuicu wasan bok.', '', 'absent', '2021-05-19T11:00:00.327Z', ''),
(60, 3, 'cardiology', 'followUp', 'Sasupmip cusivik amaup faikkuz isaudiki jirmo wo su ocuwiziko morohme nasdomsis ojerespub ciakduj ezma.', '', 'absent', '2021-05-18T17:30:00.327Z', ''),
(61, 3, 'cardiology', 'followUp', 'Akafehze la wuz og imlavwi mutota natu zojet je deze imoda rid kaz zunevez rubvim limmamo hecohube ked.', 'Gam lif lugletef ce ibouj kap unnas sozdapum pev lamfu atacu tob uzuta ew.', 'completed', '2021-05-18T14:30:00.327Z', '2021-05-18T15:00:00.327Z'),
(63, 2, 'general', 'firstVisit', 'Rurtez izrivik zoeri ipe dazjegu kopfa bob sabdepi iz ezezi ele dellog susebij.', '', 'completed', '2021-05-20T17:00:00.327Z', '2021-05-20T18:00:00.327Z'),
(64, 10, 'neurology', 'exam', 'Zar ib tos regoto midvet ipomecup digit sinpuddo gazege wipaba obizup sipog wujoc kocezu gal.', '', 'pending', '2021-05-23T10:30:00.327Z', ''),
(66, 12, 'general', 'firstVisit', 'Dahni pavtet anikelaci wurpe nom ni fuzer zez ve izwecru darzomel pi jozuc perurmi romi butkadun niuvocim kav.', 'Buj seufe ce lodit lologe had ofiwubmod al jewalo lisenuh done tumroc ruh pugik da zosoc.', 'pending', '2021-05-31T12:30:00.327Z', ''),
(67, 8, 'general', 'checkUp', 'Sojkol suw kezob ibcacheg pijdodim wik sella otli hon laabo nilulon ih zikerelu tib egehej ri.', '', 'pending', '2021-05-29T13:00:00.327Z', ''),
(68, 3, 'neurology', 'firstVisit', 'Bovto maza zelir pefuc fe zepiot najlucki tewe ujcof zalignok duk vanhe wutle goh.', 'Hak nabe roz rure pij lusatror zilduh jetvehad ak geulumuv fid ku iw bucmu bamumil.', 'pending', '2021-05-31T13:00:00.327Z', ''),
(69, 12, 'cardiology', 'firstVisit', 'Savudez juaphe evuduso owisi junderzu zar zuhag piit naujena fe hat pi akiip tu uceosa jisi ujmul vujasfek.', 'Hovra rebpiziw zawop lagasej vo vopudve za pepbej ca caki newja nudonsa ko eliuf juffuh jezsiamu poh.', 'pending', '2021-06-02T11:30:00.327Z', ''),
(70, 15, 'cardiology', 'firstVisit', 'Gebuprek pooruleg acevubfav kaboju ebaivici ez af zevo ewi ako biithiv wel.', 'Rogil kommid la neuv kaburud nal hamtaal suknut ki juigahip lodlihaba enezedde sihud fepopfup ibuerogam dum cebzi.', 'pending', '2021-05-31T11:00:00.327Z', ''),
(71, 8, 'cardiology', 'surgery', 'Wow jafep vihtup boometip ab wilaw wa aja gehbakiv duh lomidehu no sebej.', 'Lojjo disco peih waujepi ughacka vepa vafim zowca hazgu su wa il webtuk huok cefnemu heale.', 'pending', '2021-05-30T12:00:00.327Z', ''),
(72, 8, 'general', 'surgery', 'Editout dot ekiutoted paf fas caki giwes ajidavu bevefra vevidogov dimcabol ecaamwuj dup do egeufpuk pohze vu.', '', 'pending', '2021-05-31T15:30:00.327Z', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `patients`
--

CREATE TABLE `patients` (
  `patientid` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `document` text NOT NULL,
  `healthsystemid` text NOT NULL,
  `birthday` text NOT NULL,
  `insuranceplan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `patients`
--

INSERT INTO `patients` (`patientid`, `name`, `document`, `healthsystemid`, `birthday`, `insuranceplan`) VALUES
(1, 'Jack Santiago', '15055395285', '3578438116', '1978-05-24T20:39:02.196Z', 'National Premium'),
(2, 'Brett Brady', '55499461064', '4413697000', '2001-01-17T06:56:42.000Z', 'International'),
(3, 'Rachel Francis', '39413281601', '3219299364', '2012-04-07T21:47:38.602Z', 'Regional'),
(4, 'Ora Dean', '61455511117', '1536406978', '2014-11-16T03:54:33.966Z', 'International'),
(5, 'Tillie Norris', '63824751971', '9778108587', '1963-01-24T08:45:30.594Z', 'International'),
(6, 'Lucy Yates', '20490912868', '3860832164', '2010-11-26T05:45:56.631Z', 'Regional'),
(7, 'Anthony Williams', '01541400130', '1389432821', '2007-10-15T23:49:47.559Z', 'International'),
(8, 'Cynthia Gibbs', '34776232860', '0521242672', '1989-09-06T19:14:02.460Z', 'Regional'),
(9, 'Anthony Hampton', '32971526934', '7629571516', '1967-07-26T21:51:51.325Z', 'International'),
(10, 'Jane Fowler', '62110520684', '9225344992', '1985-07-30T08:18:00.966Z', 'National Basic'),
(11, 'Bill Price', '34237684605', '0575478062', '1988-06-18T15:37:19.987Z', 'National Premium'),
(12, 'Danny Green', '00646835036', '8784802395', '1970-10-07T21:07:42.434Z', 'National Basic'),
(13, 'Ada Cunningham', '70760003054', '7616756984', '2010-01-11T11:22:27.672Z', 'Diamond'),
(14, 'Edward Armstrong', '28672122177', '2408340400', '1976-05-25T02:38:47.095Z', 'National Basic'),
(15, 'Lily Larson', '36070510402', '9585234938', '1964-06-16T23:40:31.040Z', 'National Basic');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patientid`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT de tabela `patients`
--
ALTER TABLE `patients`
  MODIFY `patientid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
